// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#pragma once

#include "Math/Quat.h"
#include "Math/Vector.h"

/**
 * Core-only orientation operations, used for local mouse yaw/pitch and keyboard roll.
 * No editor, viewport, actor, UObject, or runtime camera dependencies.
 * Local translation input remains a future adapter responsibility.
 */
namespace UniversalNavigation::Math
{
    /**
     * Integrate a constant body-space angular velocity with the exponential map.
     * Controls follow UE signs: positive pitch = nose up, yaw = right, roll = right.
     * All three axes rotate with the camera. There is no world-up correction.
     */
    inline FQuat IntegrateLocalRotation(const FQuat& Orientation,
        const double PitchDegreesPerSecond, const double YawDegreesPerSecond,
        const double RollDegreesPerSecond, const double DeltaSeconds)
    {
        const FVector RotationVector = FVector(-RollDegreesPerSecond,
            -PitchDegreesPerSecond, YawDegreesPerSecond) * (UE_PI / 180.0) * DeltaSeconds;
        const double Angle = RotationVector.Size();
        FQuat Result = Orientation.GetNormalized();
        if (Angle > UE_SMALL_NUMBER)
        {
            Result = Result * FQuat(RotationVector / Angle, Angle);
            Result.Normalize();
        }
        return Result;
    }

    /** X = forward, Y = right, Z = up, expressed entirely in the camera frame. */
    inline FVector LocalDisplacementToWorld(const FQuat& Orientation, const FVector& ForwardRightUp)
    {
        return Orientation.GetNormalized().RotateVector(ForwardRightUp);
    }
}
