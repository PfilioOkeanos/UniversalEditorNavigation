// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#pragma once

#include "Modules/ModuleManager.h"
#include "UObject/WeakObjectPtr.h"

class FNativePitchPolicy;
class FLevelViewportRollInput;
class UUniversalEditorNavigationSettings;
class UEditorEngine;

class FUniversalEditorNavigationModule final : public IModuleInterface
{
public:
    virtual ~FUniversalEditorNavigationModule() override;
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;

    /** Applies the current settings without moving a camera or saving config. */
    void RefreshConfiguration();

private:
    /** Runs at OnEnginePreExit while UObject and Slate still exist; safe to call repeatedly. */
    void ReleaseEditorResources();

    TUniquePtr<FNativePitchPolicy> PitchPolicy;
    TSharedPtr<FLevelViewportRollInput> RollInput;
    TWeakObjectPtr<UUniversalEditorNavigationSettings> SettingsObject;
    TWeakObjectPtr<UEditorEngine> BoundEditor;
    FDelegateHandle SettingsChangedHandle;
    FDelegateHandle EnginePreExitHandle;
    FDelegateHandle RollClientsChangedHandle;
    FDelegateHandle AppActivationHandle;
    bool bResourcesReleased = true;
};
