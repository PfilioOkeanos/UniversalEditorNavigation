// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#pragma once

#include "Engine/DeveloperSettings.h"
#include "InputCoreTypes.h"
#include "UniversalEditorNavigationSettings.generated.h"

/** Local quaternion mouse/roll input for standard level viewports. */
UCLASS(Config=Editor, DefaultConfig, meta=(DisplayName="Universal Editor Navigation"))
class UNIVERSALEDITORNAVIGATION_API UUniversalEditorNavigationSettings final : public UDeveloperSettings
{
    GENERATED_BODY()

public:
    virtual FName GetContainerName() const override { return TEXT("Project"); }
    virtual FName GetCategoryName() const override { return TEXT("Plugins"); }

    /**
     * Enables native pitch unlock and the optional local mouse/roll adapters.
     * Does not implement local Ctrl/Space movement.
     * Changes apply immediately; disabling restores the previous pitch-lock flags.
     */
    UPROPERTY(Config, EditAnywhere, Category="Navigation", meta=(DisplayName="Enable Navigation (Local Rotation)"))
    bool bEnableUnrestrictedPitch = true;

    /** Handle RMB mouse yaw/pitch in the camera's local frame, avoiding the native world-yaw singularity after roll. */
    UPROPERTY(Config, EditAnywhere, Category="Mouse", meta=(EditCondition="bEnableUnrestrictedPitch"))
    bool bEnableLocalMouseLook = true;

    /** Multiplies Unreal's existing viewport mouse sensitivity. Native invert-Y is respected. */
    UPROPERTY(Config, EditAnywhere, Category="Mouse", meta=(ClampMin="0.05", ClampMax="5.0", EditCondition="bEnableUnrestrictedPitch && bEnableLocalMouseLook"))
    float MouseSensitivityMultiplier = 1.0f;

    /** Reserves the roll keys in the focused perspective level viewport, including without RMB.
     * Hold RMB to roll. Text fields, other editors, Ctrl/Alt/Cmd shortcuts and PIE are excluded.
     */
    UPROPERTY(Config, EditAnywhere, Category="Roll", meta=(EditCondition="bEnableUnrestrictedPitch"))
    bool bEnableRoll = true;

    UPROPERTY(Config, EditAnywhere, Category="Roll", meta=(EditCondition="bEnableUnrestrictedPitch && bEnableRoll"))
    FKey RollLeftKey = EKeys::Q;

    UPROPERTY(Config, EditAnywhere, Category="Roll", meta=(EditCondition="bEnableUnrestrictedPitch && bEnableRoll"))
    FKey RollRightKey = EKeys::E;

    UPROPERTY(Config, EditAnywhere, Category="Roll", meta=(ClampMin="1.0", ClampMax="720.0", Units="deg/s", EditCondition="bEnableUnrestrictedPitch && bEnableRoll"))
    float RollDegreesPerSecond = 120.0f;
};
