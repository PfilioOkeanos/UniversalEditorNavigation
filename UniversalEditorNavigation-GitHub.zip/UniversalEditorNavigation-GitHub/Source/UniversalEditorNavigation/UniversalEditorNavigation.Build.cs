// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

using UnrealBuildTool;

public class UniversalEditorNavigation : ModuleRules
{
    public UniversalEditorNavigation(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new[] { "Core", "CoreUObject", "DeveloperSettings", "InputCore" });
        PrivateDependencyModuleNames.AddRange(new[] { "Engine", "UnrealEd", "Slate", "SlateCore", "RenderCore" });
    }
}
