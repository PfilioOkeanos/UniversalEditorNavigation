// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#include "NativePitchPolicy.h"

#include "CameraController.h"
#include "Editor/EditorEngine.h"
#include "LevelEditorViewport.h"

FNativePitchPolicy::~FNativePitchPolicy()
{
    Stop();
}

void FNativePitchPolicy::Start(UEditorEngine& InEditor, const bool bInEnabled)
{
    Stop();
    Editor = &InEditor;
    ClientListChangedHandle = InEditor.OnLevelViewportClientListChanged().AddRaw(
        this, &FNativePitchPolicy::RefreshClients);
    SetEnabled(bInEnabled);
}

void FNativePitchPolicy::SetEnabled(const bool bInEnabled)
{
    bEnabled = bInEnabled;
    if (bEnabled)
    {
        RefreshClients();
    }
    else
    {
        RestoreClients();
    }
}

void FNativePitchPolicy::RefreshClients()
{
    UEditorEngine* EditorPtr = Editor.Get();
    if (!EditorPtr)
    {
        OriginalStates.Empty();
        return;
    }

    const auto& LiveClients = EditorPtr->GetLevelViewportClients();
    for (auto It = OriginalStates.CreateIterator(); It; ++It)
    {
        // The removal event is raised during destruction. Never dereference a removed client.
        if (!LiveClients.Contains(It.Key()))
        {
            It.RemoveCurrent();
        }
    }

    if (!bEnabled)
    {
        return;
    }

    for (FLevelEditorViewportClient* Client : LiveClients)
    {
        FEditorCameraController* Controller = Client->GetCameraController();
        if (!Controller)
        {
            continue;
        }

        if (const FOriginalState* Existing = OriginalStates.Find(Client))
        {
            if (Existing->Controller == Controller)
            {
                // Apply once, not every frame/event. Respect later changes by other editor systems.
                continue;
            }
            OriginalStates.Remove(Client);
        }

        // Include orthographic level clients: they may later switch to Perspective.
        // Their orthographic path does not use this perspective pitch-lock flag.
        OriginalStates.Add(Client, { Controller, Controller->GetConfig().bLockedPitch });
        Controller->AccessConfig().bLockedPitch = false;
    }
}

void FNativePitchPolicy::RestoreClients()
{
    if (UEditorEngine* EditorPtr = Editor.Get())
    {
        for (FLevelEditorViewportClient* Client : EditorPtr->GetLevelViewportClients())
        {
            const FOriginalState* Saved = OriginalStates.Find(Client);
            FEditorCameraController* Controller = Client->GetCameraController();
            if (Saved && Controller && Saved->Controller == Controller)
            {
                // Restore only the value this policy installed. Leave later external changes alone.
                if (!Controller->GetConfig().bLockedPitch)
                {
                    Controller->AccessConfig().bLockedPitch = Saved->bLockedPitch;
                }
            }
        }
    }
    OriginalStates.Empty();
}

void FNativePitchPolicy::Stop()
{
    if (UEditorEngine* EditorPtr = Editor.Get())
    {
        EditorPtr->OnLevelViewportClientListChanged().Remove(ClientListChangedHandle);
    }
    ClientListChangedHandle.Reset();
    RestoreClients();
    Editor.Reset();
    bEnabled = false;
}
