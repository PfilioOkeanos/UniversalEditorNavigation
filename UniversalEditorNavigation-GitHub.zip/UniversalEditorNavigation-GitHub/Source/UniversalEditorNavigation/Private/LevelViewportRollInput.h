// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#pragma once

#include "Framework/Application/IInputProcessor.h"
#include "InputCoreTypes.h"

class FLevelEditorViewportClient;
class FViewport;
class FModifierKeysState;

/**
 * Handles RMB mouse yaw/pitch and held roll keys as local quaternion input deltas.
 * Stores input/cursor state only, never a camera pose, and never reapplies an old transform.
 */
class FLevelViewportRollInput final : public IInputProcessor
{
public:
    /** An optional resolver keeps the input adapter independently testable. */
    explicit FLevelViewportRollInput(TFunction<FLevelEditorViewportClient*()> InViewportResolver = {});
    virtual ~FLevelViewportRollInput() override;

    void Configure(bool bInEnabled, FKey InLeftKey, FKey InRightKey, float InDegreesPerSecond,
        bool bInRollEnabled = true, bool bInLocalMouseLookEnabled = true, float InMouseSensitivityMultiplier = 1.0f);
    void Reset();
    virtual void Tick(float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor) override;
    virtual bool HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& Event) override;
    virtual bool HandleKeyUpEvent(FSlateApplication& SlateApp, const FKeyEvent& Event) override;
    virtual bool HandleMouseMoveEvent(FSlateApplication& SlateApp, const FPointerEvent& Event) override;
    virtual bool HandleMouseButtonUpEvent(FSlateApplication& SlateApp, const FPointerEvent& Event) override;
    virtual const TCHAR* GetDebugName() const override { return TEXT("UniversalEditorNavigation.LocalRotation"); }

    static bool IsEligibleClient(const FLevelEditorViewportClient* Client);
    static bool ApplyRollDelta(FLevelEditorViewportClient& Client, double Degrees);
    static bool ApplyLocalRotationDelta(FLevelEditorViewportClient& Client, double PitchDegrees, double YawDegrees, double RollDegrees);

private:
    FLevelEditorViewportClient* ResolveViewport() const;
    static bool IsFlightGesture(const FLevelEditorViewportClient& Client, const FModifierKeysState& Modifiers);
    void ResetKeys();
    void HideMouseCursor(FLevelEditorViewportClient& Client);
    void ReleaseMouseCursor();

    TFunction<FLevelEditorViewportClient*()> ViewportResolver;
    TSet<FKey> CapturedKeys;
    FLevelEditorViewportClient* InputOwner = nullptr; // Identity only; never dereferenced.
    FViewport* InputViewport = nullptr; // Identity only; rechecked against a live client.
    FLevelEditorViewportClient* CursorOwner = nullptr;
    FViewport* CursorViewport = nullptr;
    FKey LeftKey = EKeys::Q;
    FKey RightKey = EKeys::E;
    float DegreesPerSecond = 120.0f;
    float MouseSensitivityMultiplier = 1.0f;
    bool bEnabled = false;
    bool bRollEnabled = true;
    bool bLocalMouseLookEnabled = true;
    bool bLeftHeld = false;
    bool bRightHeld = false;
};
