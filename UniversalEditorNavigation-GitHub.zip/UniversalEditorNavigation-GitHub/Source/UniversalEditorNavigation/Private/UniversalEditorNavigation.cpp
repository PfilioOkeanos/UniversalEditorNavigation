// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#include "UniversalEditorNavigation.h"

#include "Editor.h"
#include "Framework/Application/SlateApplication.h"
#include "LevelViewportRollInput.h"
#include "Misc/CoreDelegates.h"
#include "NativePitchPolicy.h"
#include "UniversalEditorNavigationSettings.h"

DEFINE_LOG_CATEGORY_STATIC(LogUniversalEditorNavigation, Log, All);

FUniversalEditorNavigationModule::~FUniversalEditorNavigationModule() = default;

void FUniversalEditorNavigationModule::StartupModule()
{
    if (IsRunningCommandlet() || !GEditor)
    {
        return;
    }

    bResourcesReleased = false;
    BoundEditor = GEditor;
    auto* Settings = GetMutableDefault<UUniversalEditorNavigationSettings>();
    SettingsObject = Settings;
    PitchPolicy = MakeUnique<FNativePitchPolicy>();
    PitchPolicy->Start(*GEditor, Settings->bEnableUnrestrictedPitch);
    SettingsChangedHandle = Settings->OnSettingChanged().AddLambda(
        [this](UObject*, FPropertyChangedEvent&) { RefreshConfiguration(); });

    if (FSlateApplication::IsInitialized())
    {
        RollInput = MakeShared<FLevelViewportRollInput>();
        FSlateApplication::Get().RegisterInputPreProcessor(RollInput, 0);
        AppActivationHandle = FSlateApplication::Get().OnApplicationActivationStateChanged().AddLambda(
            [this](bool) { if (RollInput) { RollInput->Reset(); } });
        RollClientsChangedHandle = GEditor->OnLevelViewportClientListChanged().AddLambda(
            [this]() { if (RollInput) { RollInput->Reset(); } });
    }
    EnginePreExitHandle = FCoreDelegates::OnEnginePreExit.AddRaw(
        this, &FUniversalEditorNavigationModule::ReleaseEditorResources);
    RefreshConfiguration();

    UE_LOG(LogUniversalEditorNavigation, Display,
        TEXT("Local quaternion mouse/roll adapter loaded (navigation enabled=%s). Local Ctrl/Space translation is not installed."),
        Settings->bEnableUnrestrictedPitch ? TEXT("true") : TEXT("false"));
}

void FUniversalEditorNavigationModule::RefreshConfiguration()
{
    if (bResourcesReleased)
    {
        return;
    }
    if (const auto* Settings = SettingsObject.Get())
    {
        if (PitchPolicy)
        {
            PitchPolicy->SetEnabled(Settings->bEnableUnrestrictedPitch);
        }
        if (RollInput)
        {
            RollInput->Configure(Settings->bEnableUnrestrictedPitch,
                Settings->RollLeftKey, Settings->RollRightKey, Settings->RollDegreesPerSecond,
                Settings->bEnableRoll, Settings->bEnableLocalMouseLook, Settings->MouseSensitivityMultiplier);
        }
    }
}

void FUniversalEditorNavigationModule::ReleaseEditorResources()
{
    if (bResourcesReleased)
    {
        return;
    }
    bResourcesReleased = true;

    if (FSlateApplication::IsInitialized())
    {
        FSlateApplication::Get().OnApplicationActivationStateChanged().Remove(AppActivationHandle);
        if (RollInput)
        {
            RollInput->Reset();
            FSlateApplication::Get().UnregisterInputPreProcessor(RollInput);
        }
    }
    RollInput.Reset();
    AppActivationHandle.Reset();
    if (UEditorEngine* Editor = BoundEditor.Get())
    {
        Editor->OnLevelViewportClientListChanged().Remove(RollClientsChangedHandle);
    }
    RollClientsChangedHandle.Reset();
    if (auto* Settings = SettingsObject.Get())
    {
        Settings->OnSettingChanged().Remove(SettingsChangedHandle);
    }
    SettingsChangedHandle.Reset();
    SettingsObject.Reset();
    PitchPolicy.Reset();
    BoundEditor.Reset();
    UE_LOG(LogUniversalEditorNavigation, Display, TEXT("Editor resources released before UObject teardown/unload."));
}

void FUniversalEditorNavigationModule::ShutdownModule()
{
    FCoreDelegates::OnEnginePreExit.Remove(EnginePreExitHandle);
    EnginePreExitHandle.Reset();
    // During normal exit the early callback already cleaned everything. In particular,
    // NEVER create/access a settings CDO here after the UObject subsystem has shut down.
    ReleaseEditorResources();
}

IMPLEMENT_MODULE(FUniversalEditorNavigationModule, UniversalEditorNavigation)
