// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

class UEditorEngine;
class FLevelEditorViewportClient;
class FEditorCameraController;

/** Owns only a native configuration flag. Never owns or replaces a viewport/client. */
class FNativePitchPolicy final
{
public:
    ~FNativePitchPolicy();
    void Start(UEditorEngine& InEditor, bool bInEnabled);
    void SetEnabled(bool bInEnabled);
    void Stop();

private:
    struct FOriginalState
    {
        FEditorCameraController* Controller = nullptr;
        bool bLockedPitch = true;
    };

    void RefreshClients();
    void RestoreClients();

    TWeakObjectPtr<UEditorEngine> Editor;
    TMap<FLevelEditorViewportClient*, FOriginalState> OriginalStates;
    FDelegateHandle ClientListChangedHandle;
    bool bEnabled = false;
};
