// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#include "LevelViewportRollInput.h"

#if WITH_DEV_AUTOMATION_TESTS

#include "CameraController.h"
#include "Editor.h"
#include "Framework/Application/SlateApplication.h"
#include "Input/Events.h"
#include "LevelEditorViewport.h"
#include "Misc/AutomationTest.h"
#include "Misc/ScopeExit.h"
#include "MouseDeltaTracker.h"
#include "Slate/SceneViewport.h"
#include "Settings/LevelEditorViewportSettings.h"
#include "UniversalNavigationMath.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FUniversalNativeRollTest,
    "UniversalEditorNavigation.Editor.LocalRollQuaternionAdapter",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FUniversalNativeRollTest::RunTest(const FString&)
{
    auto Client = MakeUnique<FLevelEditorViewportClient>(TSharedPtr<SLevelViewport>());
    Client->ViewportType = LVT_Perspective;
    Client->GetCameraController()->AccessConfig().bLockedPitch = false;
    Client->GetCameraController()->AccessConfig().bUsePhysicsBasedRotation = false;
    const FVector Location(150, 260, 370);
    Client->SetViewLocation(Location);
    const FRotator InitialViews[] = {
        FRotator(0, 0, 0), FRotator(45, 37, 21), FRotator(89.999, 70, 54),
        FRotator(-89.999, -40, -91), FRotator(90, 30, 18),
        FRotator(-90, -62, 29), FRotator(12, 35, 180)
    };
    for (const FRotator& Initial : InitialViews)
    {
        Client->SetViewRotation(Initial);
        const FQuat Start = Client->GetViewRotation().Quaternion();
        FQuat Expected = Start;
        for (int32 Step = 0; Step < 240; ++Step)
        {
            TestTrue(TEXT("Local roll input accepted"), FLevelViewportRollInput::ApplyRollDelta(*Client, 1.5));
            Expected = UniversalNavigation::Math::IntegrateLocalRotation(Expected, 0, 0, 90, 1.0 / 60.0);
            TestTrue(TEXT("Viewport roll agrees with local quaternion integration, including at the poles"),
                Client->GetViewRotation().Quaternion().Equals(Expected, 1.e-4));
        }
        TestTrue(TEXT("Full local roll returns to original orientation"),
            Client->GetViewRotation().Quaternion().Equals(Start, 1.e-4));
        TestTrue(TEXT("Local roll preserves forward direction"),
            Client->GetViewRotation().Vector().Equals(Start.GetForwardVector(), 1.e-4));
        TestTrue(TEXT("Rolling does not translate the camera"), Client->GetViewLocation().Equals(Location));
    }
    return true;
}

namespace
{
    /** Deterministic Slate viewport state; no real mouse injection or user window focus changes. */
    class FRollTestViewport final : public FSceneViewport
    {
    public:
        FRollTestViewport() : FSceneViewport(TSharedPtr<SViewport>()) {}
        virtual bool HasFocus() const override { return bFocused; }
        virtual bool IsForegroundWindow() const override { return bForeground; }
        virtual bool HasMouseCapture() const override { return bCaptured; }
        virtual bool KeyState(FKey Key) const override { return Buttons.Contains(Key); }

        TSet<FKey> Buttons;
        bool bFocused = true;
        bool bForeground = true;
        bool bCaptured = false;
    };
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FUniversalRollInputTest,
    "UniversalEditorNavigation.Editor.RollInputScopeAndRelease",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FUniversalRollInputTest::RunTest(const FString&)
{
    if (!GEditor || !FSlateApplication::IsInitialized())
    {
        AddError(TEXT("Requires an initialized editor and Slate."));
        return false;
    }
    auto Client = MakeUnique<FLevelEditorViewportClient>(TSharedPtr<SLevelViewport>());
    Client->ViewportType = LVT_Perspective;
    Client->GetCameraController()->AccessConfig().bLockedPitch = false;
    Client->GetCameraController()->AccessConfig().bUsePhysicsBasedRotation = false;
    FRollTestViewport Viewport;
    Client->Viewport = &Viewport;
    ON_SCOPE_EXIT { Client->Viewport = nullptr; };
    FLevelViewportRollInput Input([&]() { return Client.Get(); });
    Input.Configure(true, EKeys::Q, EKeys::E, 90);
    FSlateApplication& Slate = FSlateApplication::Get();
    const auto Cursor = Slate.GetPlatformCursor().ToSharedRef();
    const auto KeyEvent = [](FKey Key, bool bRepeat = false)
    {
        return FKeyEvent(Key, FModifierKeysState(), 0, bRepeat, 0, 0);
    };
    Client->SetViewRotation(FRotator::ZeroRotator);

    TestTrue(TEXT("Q is reserved before RMB, preventing native Q movement when RMB is later pressed"),
        Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestTrue(TEXT("No rotation without RMB"), Client->GetViewRotation().IsNearlyZero());
    Viewport.Buttons.Add(EKeys::RightMouseButton);
    Viewport.bCaptured = true;
    for (int32 Frame = 0; Frame < 60; ++Frame)
    {
        TestTrue(TEXT("OS repeat is consumed"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q, true)));
        Input.Tick(1.0f / 60, Slate, Cursor);
    }
    TestTrue(TEXT("Q rolls left at 90 degrees per second"),
        Client->GetViewRotation().Quaternion().Equals(FRotator(0, 0, -90).Quaternion(), 1.e-5));
    TestTrue(TEXT("Keyboard roll suppresses the RMB context menu using native movement bookkeeping"),
        Client->GetMouseDeltaTracker()->WasExternalMovement());
    TestTrue(TEXT("Captured Q release is consumed"), Input.HandleKeyUpEvent(Slate, KeyEvent(EKeys::Q)));
    const FQuat Stopped = Client->GetViewRotation().Quaternion();
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestTrue(TEXT("Release stops roll without resetting orientation"), Client->GetViewRotation().Quaternion().Equals(Stopped));

    TestTrue(TEXT("E captured"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::E)));
    for (int32 Frame = 0; Frame < 60; ++Frame) { Input.Tick(1.0f / 60, Slate, Cursor); }
    TestTrue(TEXT("E rolls right and reverses Q"), Client->GetViewRotation().Quaternion().Equals(FQuat::Identity, 1.e-5));
    TestTrue(TEXT("Q captured alongside E"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestTrue(TEXT("Opposing keys cancel"), Client->GetViewRotation().Quaternion().Equals(FQuat::Identity, 1.e-5));

    Input.HandleKeyUpEvent(Slate, KeyEvent(EKeys::E));
    Viewport.Buttons.Remove(EKeys::RightMouseButton);
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestTrue(TEXT("RMB release stops roll with Q still down"), Client->GetViewRotation().Quaternion().Equals(FQuat::Identity, 1.e-5));
    Viewport.Buttons.Add(EKeys::RightMouseButton);
    Viewport.bFocused = false;
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestFalse(TEXT("No interception in text fields or after viewport focus loss"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Viewport.bFocused = true;
    Input.Tick(1.0f / 60, Slate, Cursor);
    TestTrue(TEXT("Focus recovery cannot resume a stale held key"), Client->GetViewRotation().Quaternion().Equals(FQuat::Identity, 1.e-5));

    TestFalse(TEXT("Ctrl+S is never intercepted"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::S)));
    const FModifierKeysState Ctrl(false, false, true, false, false, false, false, false, false);
    TestFalse(TEXT("Ctrl+Q shortcuts are not reserved"),
        Input.HandleKeyDownEvent(Slate, FKeyEvent(EKeys::Q, Ctrl, 0, false, 0, 0)));
    Viewport.bForeground = false;
    TestFalse(TEXT("No capture in a background window"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Viewport.bForeground = true;
    Client->ViewportType = LVT_OrthoXY;
    TestFalse(TEXT("Orthographic viewports keep their Q/E behavior"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Client->ViewportType = LVT_Perspective;
    Client->GetCameraController()->AccessConfig().bUsePhysicsBasedRotation = true;
    TestFalse(TEXT("Unsupported rotational physics is left untouched"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));
    Client->GetCameraController()->AccessConfig().bUsePhysicsBasedRotation = false;

    Input.Configure(false, EKeys::Q, EKeys::E, 90);
    TestFalse(TEXT("Disabled roll restores native Q/E"), Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::Q)));

    Input.Configure(true, EKeys::Q, EKeys::E, 120);
    Client->SetViewRotation(FRotator::ZeroRotator);
    Input.HandleKeyDownEvent(Slate, KeyEvent(EKeys::E));
    for (int32 Frame = 0; Frame < 60; ++Frame) { Input.Tick(1.0f / 60, Slate, Cursor); }
    TestTrue(TEXT("Requested faster roll runs at 120 degrees per second"),
        Client->GetViewRotation().Quaternion().Equals(FRotator(0, 0, 120).Quaternion(), 1.e-5));
    Input.Reset();
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FUniversalLocalMouseTest,
    "UniversalEditorNavigation.Editor.MouseAfterSideRollRegression",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FUniversalLocalMouseTest::RunTest(const FString&)
{
    auto Client = MakeUnique<FLevelEditorViewportClient>(TSharedPtr<SLevelViewport>());
    Client->ViewportType = LVT_Perspective;
    Client->GetCameraController()->AccessConfig().bLockedPitch = false;
    Client->GetCameraController()->AccessConfig().bUsePhysicsBasedRotation = false;
    FRollTestViewport Viewport;
    Client->Viewport = &Viewport;
    ON_SCOPE_EXIT { Client->Viewport = nullptr; };
    Viewport.bCaptured = true;
    Viewport.Buttons.Add(EKeys::RightMouseButton);
    FLevelViewportRollInput Input([&]() { return Client.Get(); });
    Input.Configure(true, EKeys::Q, EKeys::E, 120);
    FSlateApplication& Slate = FSlateApplication::Get();
    const auto MouseEvent = [&](double X, double Y, FModifierKeysState Modifiers = {})
    {
        // A raw event can have unchanged screen coordinates but nonzero deltas.
        // Use that exact form to catch cursor-position based/bounded implementations.
        return FPointerEvent(0, 0, FVector2D(300, 300), FVector2D(300, 300),
            FVector2D(X, Y), Viewport.Buttons, Modifiers);
    };
    auto* ViewportSettings = GetMutableDefault<ULevelEditorViewportSettings>();
    const float OldSensitivity = ViewportSettings->MouseSensitivty;
    const bool bOldInvert = ViewportSettings->bInvertMouseLookYAxis;
    ON_SCOPE_EXIT
    {
        ViewportSettings->MouseSensitivty = OldSensitivity;
        ViewportSettings->bInvertMouseLookYAxis = bOldInvert;
    };
    ViewportSettings->MouseSensitivty = 1.0f;
    ViewportSettings->bInvertMouseLookYAxis = false;
    const FVector Location(123, 456, 789);
    Client->SetViewLocation(Location);

    for (const double Roll : { -90.0, 90.0 })
    {
        const FRotator Initial(0, 0, Roll);
        const FQuat Start = Initial.Quaternion();
        const FVector Forward = Start.GetForwardVector();

        // Reproduce the v0.2/native failure: world yaw and local pitch collapse
        // into the same tangent direction at exactly 90 degrees of camera roll.
        Client->SetViewRotation(Initial);
        Client->MoveViewportCamera(FVector::ZeroVector, FRotator(0, 1, 0));
        const FVector OldYawTangent = (Client->GetViewRotation().Vector() - Forward).GetSafeNormal();
        Client->SetViewRotation(Initial);
        Client->MoveViewportCamera(FVector::ZeroVector, FRotator(1, 0, 0));
        const FVector OldPitchTangent = (Client->GetViewRotation().Vector() - Forward).GetSafeNormal();
        TestTrue(TEXT("Regression reproduced: native mouse axes collapse after side roll"),
            FMath::Abs(FVector::DotProduct(OldYawTangent, OldPitchTangent)) > 0.999);

        Client->SetViewRotation(Initial);
        TestTrue(TEXT("Local yaw event consumed before native accumulation"), Input.HandleMouseMoveEvent(Slate, MouseEvent(1, 0)));
        const FVector NewYawTangent = (Client->GetViewRotation().Vector() - Forward).GetSafeNormal();
        TestTrue(TEXT("Mouse yaw follows local camera up after side roll"),
            Client->GetViewRotation().Quaternion().Equals(Start * FRotator(0, 1, 0).Quaternion(), 1.e-5));
        Client->SetViewRotation(Initial);
        TestTrue(TEXT("Local pitch event consumed before native accumulation"), Input.HandleMouseMoveEvent(Slate, MouseEvent(0, -1)));
        const FVector NewPitchTangent = (Client->GetViewRotation().Vector() - Forward).GetSafeNormal();
        TestTrue(TEXT("Corrected yaw/pitch axes remain independent"),
            FMath::Abs(FVector::DotProduct(NewYawTangent, NewPitchTangent)) < 0.001);

        Client->SetViewRotation(Initial);
        for (int32 Step = 1; Step <= 1080; ++Step)
        {
            Input.HandleMouseMoveEvent(Slate, MouseEvent(0, -1));
            if (Step % 90 == 0)
            {
                const FQuat Expected = Start * FRotator(Step, 0, 0).Quaternion();
                TestTrue(TEXT("Three full local pitch loops after side roll cross every quarter-turn without clamping"),
                    Client->GetViewRotation().Quaternion().Equals(Expected, 1.e-4));
            }
        }
        Client->SetViewRotation(Initial);
        for (int32 Step = 1; Step <= 1080; ++Step)
        {
            Input.HandleMouseMoveEvent(Slate, MouseEvent(1, 0));
            if (Step % 90 == 0)
            {
                // At 90-degree roll this local yaw crosses the WORLD zenith/nadir,
                // exercising the native Rotator storage boundary at its singularities.
                const FQuat Expected = Start * FRotator(0, Step, 0).Quaternion();
                TestTrue(TEXT("Three full local yaw loops after side roll cross the world poles without clamping"),
                    Client->GetViewRotation().Quaternion().Equals(Expected, 1.e-4));
            }
        }
        TestTrue(TEXT("Mouse rotation preserves camera position"), Client->GetViewLocation().Equals(Location));
    }

    Client->SetViewRotation(FRotator::ZeroRotator);
    ViewportSettings->bInvertMouseLookYAxis = true;
    Input.HandleMouseMoveEvent(Slate, MouseEvent(0, 10));
    TestTrue(TEXT("Native invert-Y is respected"), Client->GetViewRotation().Quaternion().Equals(FRotator(10, 0, 0).Quaternion(), 1.e-5));
    ViewportSettings->bInvertMouseLookYAxis = false;
    Input.Configure(true, EKeys::Q, EKeys::E, 120, true, true, 2);
    Client->SetViewRotation(FRotator::ZeroRotator);
    Input.HandleMouseMoveEvent(Slate, MouseEvent(5, 0));
    TestTrue(TEXT("Mouse sensitivity multiplier works"), Client->GetViewRotation().Quaternion().Equals(FRotator(0, 10, 0).Quaternion(), 1.e-5));
    Input.Configure(true, EKeys::Q, EKeys::E, 120);
    Viewport.Buttons.Remove(EKeys::RightMouseButton);
    const FQuat BeforeNoRMB = Client->GetViewRotation().Quaternion();
    TestFalse(TEXT("Mouse input without RMB remains native"), Input.HandleMouseMoveEvent(Slate, MouseEvent(10, 10)));
    TestTrue(TEXT("No rotation applied outside RMB gesture"), Client->GetViewRotation().Quaternion().Equals(BeforeNoRMB));
    Viewport.Buttons.Add(EKeys::RightMouseButton);
    const FModifierKeysState Alt(false, false, false, false, true, false, false, false, false);
    TestFalse(TEXT("Alt orbit remains native"), Input.HandleMouseMoveEvent(Slate, MouseEvent(10, 10, Alt)));
    Viewport.bFocused = false;
    TestFalse(TEXT("Mouse input in other focus stays native"), Input.HandleMouseMoveEvent(Slate, MouseEvent(10, 10)));
    Viewport.bFocused = true;
    Input.Configure(true, EKeys::Q, EKeys::E, 120, true, false);
    TestFalse(TEXT("Local mouse look can be independently disabled"), Input.HandleMouseMoveEvent(Slate, MouseEvent(10, 10)));
    Input.Reset();
    return true;
}

#endif
