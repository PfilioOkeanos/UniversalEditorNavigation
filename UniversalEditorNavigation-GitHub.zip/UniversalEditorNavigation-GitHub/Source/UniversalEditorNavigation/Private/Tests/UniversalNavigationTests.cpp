// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#include "UniversalNavigationMath.h"

#if WITH_DEV_AUTOMATION_TESTS

#include "CameraController.h"
#include "Editor.h"
#include "LevelEditorViewport.h"
#include "Misc/AutomationTest.h"
#include "Misc/ScopeExit.h"
#include "UniversalEditorNavigationSettings.h"
#include "UObject/UnrealType.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FUniversalOrientationTest,
    "UniversalEditorNavigation.Math.LocalQuaternionIntegration",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FUniversalOrientationTest::RunTest(const FString&)
{
    using namespace UniversalNavigation::Math;
    FQuat Orientation = FQuat::Identity;
    for (int32 Frame = 0; Frame < 2400; ++Frame)
    {
        Orientation = IntegrateLocalRotation(Orientation, 180.0, 0.0, 0.0, 1.0 / 240.0);
        TestTrue(TEXT("Quaternion remains normalized through five loops"), Orientation.IsNormalized());
        if (Frame == 239)
        {
            TestTrue(TEXT("Pitch crosses the pole and faces backward"),
                Orientation.GetForwardVector().Equals(-FVector::ForwardVector, 1.e-6));
        }
    }
    TestTrue(TEXT("Five full loops return to the same orientation"), Orientation.Equals(FQuat::Identity, 1.e-6));

    const FQuat Rolled = IntegrateLocalRotation(FQuat::Identity, 0, 0, 90, 1);
    TestTrue(TEXT("Roll preserves the viewing direction"),
        Rolled.GetForwardVector().Equals(FVector::ForwardVector, 1.e-6));
    TestTrue(TEXT("Roll follows Unreal's control sign convention"),
        Rolled.Equals(FRotator(0, 0, 90).Quaternion(), 1.e-6));
    const FQuat LocalYaw = IntegrateLocalRotation(Rolled, 0, 90, 0, 1);
    const FVector ExpectedForward = Rolled.RotateVector(FVector::RightVector);
    TestTrue(TEXT("Yaw follows rolled local up, not world up"),
        LocalYaw.GetForwardVector().Equals(ExpectedForward, 1.e-6));

    const FQuat UpsideDown = IntegrateLocalRotation(FQuat::Identity, 0, 0, 180, 1);
    TestTrue(TEXT("Local Space/up points toward world down when inverted"),
        LocalDisplacementToWorld(UpsideDown, FVector::UpVector).Equals(-FVector::UpVector, 1.e-6));

    const FQuat Initial = FRotator(38, -67, 122).Quaternion();
    FQuat Mixed = Initial;
    for (int32 Frame = 0; Frame < 20000; ++Frame)
    {
        Mixed = IntegrateLocalRotation(Mixed, 77, -31, 103, 1.0 / 240.0);
    }
    for (int32 Frame = 0; Frame < 20000; ++Frame)
    {
        Mixed = IntegrateLocalRotation(Mixed, -77, 31, -103, 1.0 / 240.0);
    }
    TestTrue(TEXT("Long mixed-axis sequence reverses without drift"), Mixed.Equals(Initial, 1.e-6));
    TestTrue(TEXT("Vector length is preserved"),
        FMath::IsNearlyEqual(LocalDisplacementToWorld(Mixed, FVector(1, 2, 3)).Size(), FVector(1, 2, 3).Size(), 1.e-6));
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FUniversalNativePolicyTest,
    "UniversalEditorNavigation.Editor.NativePitchLifecycle",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FUniversalNativePolicyTest::RunTest(const FString&)
{
    if (!GEditor || IsRunningCommandlet())
    {
        AddError(TEXT("Requires an initialized editor, not a commandlet."));
        return false;
    }

    auto* Settings = GetMutableDefault<UUniversalEditorNavigationSettings>();
    const bool bOriginalSetting = Settings->bEnableUnrestrictedPitch;
    auto SetEnabled = [Settings](const bool bEnabled)
    {
        Settings->bEnableUnrestrictedPitch = bEnabled;
        FPropertyChangedEvent Event(FindFProperty<FBoolProperty>(Settings->GetClass(),
            GET_MEMBER_NAME_CHECKED(UUniversalEditorNavigationSettings, bEnableUnrestrictedPitch)));
        // Notify exactly the settings delegate used by the UI, without saving any config.
        Settings->OnSettingChanged().Broadcast(Settings, Event);
    };
    ON_SCOPE_EXIT { SetEnabled(bOriginalSetting); };

    SetEnabled(false);
    auto Client = MakeUnique<FLevelEditorViewportClient>(TSharedPtr<SLevelViewport>());
    Client->ViewportType = LVT_Perspective;
    FCameraControllerConfig& Config = Client->GetCameraController()->AccessConfig();
    TestTrue(TEXT("Native default locks pitch while disabled"), Config.bLockedPitch);
    const FVector InitialLocation(120, 230, 340);
    const FRotator InitialRotation(25, 35, 45);
    Client->SetViewLocation(InitialLocation);
    Client->SetViewRotation(InitialRotation);

    SetEnabled(true);
    TestFalse(TEXT("Existing level client is unlocked"), Config.bLockedPitch);
    TestTrue(TEXT("Enabling does not move the camera"), Client->GetViewLocation().Equals(InitialLocation));
    TestTrue(TEXT("Enabling preserves roll and orientation"), Client->GetViewRotation().Equals(InitialRotation));

    {
        auto Other = MakeUnique<FLevelEditorViewportClient>(TSharedPtr<SLevelViewport>());
        TestFalse(TEXT("New level client is automatically unlocked"), Other->GetCameraController()->GetConfig().bLockedPitch);
    }
    SetEnabled(false);
    TestTrue(TEXT("Disabling restores original lock after another client was destroyed"), Config.bLockedPitch);
    TestTrue(TEXT("Disabling preserves orientation"), Client->GetViewRotation().Equals(InitialRotation));

    Config.bLockedPitch = false;
    SetEnabled(true);
    SetEnabled(false);
    TestFalse(TEXT("Originally unlocked client stays unlocked"), Config.bLockedPitch);

    Config.bLockedPitch = true;
    SetEnabled(true);
    Config.bLockedPitch = true; // A later external owner changed this flag.
    SetEnabled(false);
    TestTrue(TEXT("Later external configuration is respected"), Config.bLockedPitch);
    return true;
}

#endif
