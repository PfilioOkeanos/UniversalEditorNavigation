// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Pfilio_okeanos

#include "LevelViewportRollInput.h"

#include "CameraController.h"
#include "Editor.h"
#include "Framework/Application/SlateApplication.h"
#include "Input/Events.h"
#include "LevelEditorViewport.h"
#include "MouseDeltaTracker.h"
#include "Settings/LevelEditorViewportSettings.h"
#include "UniversalNavigationMath.h"
#include "UnrealClient.h"

FLevelViewportRollInput::FLevelViewportRollInput(TFunction<FLevelEditorViewportClient*()> InViewportResolver)
    : ViewportResolver(MoveTemp(InViewportResolver))
{
}

void FLevelViewportRollInput::Configure(const bool bInEnabled, const FKey InLeftKey,
    const FKey InRightKey, const float InDegreesPerSecond, const bool bInRollEnabled,
    const bool bInLocalMouseLookEnabled, const float InMouseSensitivityMultiplier)
{
    Reset();
    const auto IsKeyboardKey = [](const FKey& Key)
    {
        return Key.IsValid() && !Key.IsModifierKey() && !Key.IsMouseButton()
            && !Key.IsGamepadKey() && !Key.IsAxis1D() && !Key.IsAxis2D() && !Key.IsAxis3D();
    };
    bEnabled = bInEnabled;
    bLocalMouseLookEnabled = bInLocalMouseLookEnabled;
    bRollEnabled = bInRollEnabled && IsKeyboardKey(InLeftKey) && IsKeyboardKey(InRightKey)
        && InLeftKey != InRightKey;
    LeftKey = InLeftKey;
    RightKey = InRightKey;
    DegreesPerSecond = FMath::IsFinite(InDegreesPerSecond)
        ? FMath::Clamp(InDegreesPerSecond, 1.0f, 720.0f) : 120.0f;
    MouseSensitivityMultiplier = FMath::IsFinite(InMouseSensitivityMultiplier)
        ? FMath::Clamp(InMouseSensitivityMultiplier, 0.05f, 5.0f) : 1.0f;
}

FLevelViewportRollInput::~FLevelViewportRollInput()
{
    Reset();
}

void FLevelViewportRollInput::ResetKeys()
{
    CapturedKeys.Empty();
    bLeftHeld = bRightHeld = false;
    InputOwner = nullptr;
    InputViewport = nullptr;
}

void FLevelViewportRollInput::Reset()
{
    ReleaseMouseCursor();
    ResetKeys();
}

void FLevelViewportRollInput::HideMouseCursor(FLevelEditorViewportClient& Client)
{
    if (CursorOwner != &Client || CursorViewport != Client.Viewport)
    {
        ReleaseMouseCursor();
        CursorOwner = &Client;
        CursorViewport = Client.Viewport;
    }
    Client.SetRequiredCursorOverride(true, EMouseCursor::None);
}

void FLevelViewportRollInput::ReleaseMouseCursor()
{
    // Removed clients are never dereferenced. The module resets this adapter on
    // client-list changes, application deactivation, settings changes and pre-exit.
    if (CursorOwner && GEditor && GEditor->GetLevelViewportClients().Contains(CursorOwner)
        && CursorOwner->Viewport == CursorViewport)
    {
        CursorOwner->SetRequiredCursorOverride(false);
    }
    CursorOwner = nullptr;
    CursorViewport = nullptr;
}

bool FLevelViewportRollInput::IsEligibleClient(const FLevelEditorViewportClient* Client)
{
    if (!Client || !Client->Viewport || !Client->IsPerspective() || Client->bDisableInput
        || Client->IsCameraLocked() || Client->IsAnyActorLocked()
        || Client->GetCurrentWidgetAxis() != EAxisList::None)
    {
        return false;
    }
    return Client->Viewport->HasFocus() && Client->Viewport->IsForegroundWindow();
}

FLevelEditorViewportClient* FLevelViewportRollInput::ResolveViewport() const
{
    if (!bEnabled || !GEditor || GEditor->PlayWorld || GEditor->bIsSimulatingInEditor)
    {
        return nullptr;
    }
    auto IsUsable = [](FLevelEditorViewportClient* Client)
    {
        if (!IsEligibleClient(Client))
        {
            return false;
        }
        FEditorCameraController* Controller = Client->GetCameraController();
        // The native rotational-physics path uses velocity modifiers rather than
        // exact angular deltas. Do not silently change its behavior or claim exact speed.
        return Controller && !Controller->GetConfig().bUsePhysicsBasedRotation
            && !Controller->GetConfig().bLockedPitch;
    };
    if (ViewportResolver)
    {
        FLevelEditorViewportClient* Client = ViewportResolver();
        return IsUsable(Client) ? Client : nullptr;
    }
    for (FLevelEditorViewportClient* Client : GEditor->GetLevelViewportClients())
    {
        if (IsUsable(Client))
        {
            return Client;
        }
    }
    return nullptr;
}

bool FLevelViewportRollInput::HandleKeyDownEvent(FSlateApplication&, const FKeyEvent& Event)
{
    const FKey Key = Event.GetKey();
    if (CapturedKeys.Contains(Key))
    {
        return true; // OS repeats must not restart or double the held-key movement.
    }
    if (!bEnabled || !bRollEnabled || Event.IsRepeat() || (Key != LeftKey && Key != RightKey)
        || Event.IsControlDown() || Event.IsAltDown() || Event.IsCommandDown())
    {
        return false;
    }
    FLevelEditorViewportClient* Client = ResolveViewport();
    if (!Client)
    {
        return false;
    }
    if (InputOwner != Client || InputViewport != Client->Viewport)
    {
        ResetKeys();
        InputOwner = Client;
        InputViewport = Client->Viewport;
    }
    CapturedKeys.Add(Key);
    if (Key == LeftKey) { bLeftHeld = true; }
    if (Key == RightKey) { bRightHeld = true; }
    // The user explicitly permits reserving Q/E in the focused level viewport.
    // Swallowing before FSceneViewport sees key-down also prevents its native
    // per-frame Q/E up/down polling, including keys held BEFORE RMB is pressed.
    return true;
}

bool FLevelViewportRollInput::HandleKeyUpEvent(FSlateApplication&, const FKeyEvent& Event)
{
    const FKey Key = Event.GetKey();
    const bool bWasCaptured = CapturedKeys.Remove(Key) > 0;
    if (Key == LeftKey) { bLeftHeld = false; }
    if (Key == RightKey) { bRightHeld = false; }
    return bWasCaptured;
}

void FLevelViewportRollInput::Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor>)
{
    FLevelEditorViewportClient* Client = ResolveViewport();
    if (!Client)
    {
        Reset();
        return;
    }
    const FModifierKeysState Modifiers = SlateApp.GetModifierKeys();
    if (CursorOwner && (CursorOwner != Client || CursorViewport != Client->Viewport))
    {
        ReleaseMouseCursor();
    }
    if (!IsFlightGesture(*Client, Modifiers))
    {
        ReleaseMouseCursor();
        return;
    }
    if (!bRollEnabled || Client != InputOwner || Client->Viewport != InputViewport)
    {
        ResetKeys();
        return;
    }
    const int32 Direction = static_cast<int32>(bRightHeld) - static_cast<int32>(bLeftHeld);
    if (Direction == 0 || !FMath::IsFinite(DeltaTime) || DeltaTime <= 0)
    {
        return;
    }
    // Integrate held input only. Limit hitch movement; do not catch up by teleporting.
    const double Degrees = Direction * DegreesPerSecond * FMath::Min(DeltaTime, 0.05f);
    if (ApplyRollDelta(*Client, Degrees))
    {
        HideMouseCursor(*Client);
    }
}

bool FLevelViewportRollInput::ApplyRollDelta(FLevelEditorViewportClient& Client, const double Degrees)
{
    return ApplyLocalRotationDelta(Client, 0, 0, Degrees);
}

bool FLevelViewportRollInput::IsFlightGesture(const FLevelEditorViewportClient& Client, const FModifierKeysState& Modifiers)
{
    return Client.Viewport && Client.Viewport->HasMouseCapture()
        && Client.Viewport->KeyState(EKeys::RightMouseButton)
        && !Client.Viewport->KeyState(EKeys::LeftMouseButton) && !Client.Viewport->KeyState(EKeys::MiddleMouseButton)
        && !Modifiers.IsAltDown() && !Modifiers.IsControlDown() && !Modifiers.IsCommandDown();
}

bool FLevelViewportRollInput::HandleMouseMoveEvent(FSlateApplication& SlateApp, const FPointerEvent& Event)
{
    if (!bLocalMouseLookEnabled || Event.IsTouchEvent() || SlateApp.IsUsingTrackpad())
    {
        return false;
    }
    FLevelEditorViewportClient* Client = ResolveViewport();
    if (!Client || !IsFlightGesture(*Client, Event.GetModifierKeys())
        || !Event.IsMouseButtonDown(EKeys::RightMouseButton))
    {
        return false;
    }
    const FVector2D Delta = Event.GetCursorDelta();
    if (!FMath::IsFinite(Delta.X) || !FMath::IsFinite(Delta.Y))
    {
        return false;
    }
    const auto* ViewportSettings = GetDefault<ULevelEditorViewportSettings>();
    const double Sensitivity = ViewportSettings->MouseSensitivty * MouseSensitivityMultiplier;
    const double Pitch = -Delta.Y * Sensitivity * (ViewportSettings->bInvertMouseLookYAxis ? -1.0 : 1.0);
    const double Yaw = Delta.X * Sensitivity;
    if (ApplyLocalRotationDelta(*Client, Pitch, Yaw, 0))
    {
        HideMouseCursor(*Client);
        // Consume the actual mouse event before FSceneViewport accumulates native
        // Euler/world-yaw input. Otherwise the same input would rotate twice.
        return true;
    }
    return false;
}

bool FLevelViewportRollInput::HandleMouseButtonUpEvent(FSlateApplication&, const FPointerEvent& Event)
{
    if (Event.GetEffectingButton() == EKeys::RightMouseButton)
    {
        ReleaseMouseCursor();
    }
    return false; // Native button-up must always release mouse capture normally.
}

bool FLevelViewportRollInput::ApplyLocalRotationDelta(FLevelEditorViewportClient& Client,
    const double PitchDegrees, const double YawDegrees, const double RollDegrees)
{
    FEditorCameraController* Controller = Client.GetCameraController();
    if (!Client.IsPerspective() || !Controller || Controller->GetConfig().bLockedPitch
        || Controller->GetConfig().bUsePhysicsBasedRotation || !FMath::IsFinite(PitchDegrees)
        || !FMath::IsFinite(YawDegrees) || !FMath::IsFinite(RollDegrees))
    {
        return false;
    }
    if (FMath::IsNearlyZero(PitchDegrees) && FMath::IsNearlyZero(YawDegrees) && FMath::IsNearlyZero(RollDegrees))
    {
        return true;
    }
    Client.ToggleOrbitCamera(false);
    const FVector Location = Client.GetViewLocation();
    const double LookAtDistance = FVector::Distance(Location, Client.GetLookAtLocation());
    const FQuat Result = UniversalNavigation::Math::IntegrateLocalRotation(
        Client.GetViewRotation().Quaternion(), PitchDegrees, YawDegrees, RollDegrees, 1);
    // Apply only this input delta, using the CURRENT orientation as the source.
    // No camera pose survives the call, and nothing is enforced on a later frame.
    // Rotator is solely the public viewport storage boundary; no Euler addition/clamp.
    Client.SetViewRotation(Result.Rotator());
    Client.SetLookAtLocation(Location + Result.GetForwardVector() * LookAtDistance);
    // Re-enter the public native movement path with ZERO additional rotation to
    // perform its normal camera-moved/audio notifications. The actual orientation
    // above was computed locally as a quaternion; no native yaw delta is supplied.
    Client.MoveViewportCamera(FVector::ZeroVector, FRotator::ZeroRotator);
    Client.GetMouseDeltaTracker()->SetExternalMovement();
    Client.Invalidate(false, false);
    return true;
}
