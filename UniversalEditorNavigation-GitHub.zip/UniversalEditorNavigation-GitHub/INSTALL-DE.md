# Installation in Unreal Engine – Windows

Diese Anleitung beschreibt die Installation des **Quellcode-Plugins** Universal Editor Navigation in ein eigenes Unreal-Projekt. Geprüft sind **Unreal Engine 5.8.3 und Windows/Win64**. Andere Versionen und Plattformen sind bisher nicht verifiziert.

Das GitHub-Paket enthält keine fertige Editor-DLL. Sie entsteht beim Kompilieren auf deinem Rechner. Dein Projekt darf ein anderes sein als das Projekt, in dem das Plugin entwickelt wurde.

## 1. C++-Werkzeuge vorbereiten

Installiere Unreal Engine 5.8.3 und eine passende Visual-Studio-C++-Umgebung. Epic empfiehlt für UE 5.8 Visual Studio 2026 ab 18.0; unterstützt wird auch Visual Studio 2022 ab 17.14.

Öffne den **Visual Studio Installer**, wähle bei deiner Installation **Ändern / Modify** und richte die von Epic genannten C++-Workloads und Komponenten ein. Für Unreal gehören insbesondere **Spieleentwicklung mit C++ / Game development with C++**, ein passender MSVC-Compiler und das Windows SDK dazu.

Die aktuelle Versions- und Komponentenliste steht in [Epics Visual-Studio-Anleitung](https://dev.epicgames.com/documentation/en-us/unreal-engine/setting-up-visual-studio-development-environment-for-cplusplus-projects-in-unreal-engine). Wenn Visual Studio beim Öffnen des Projekts fehlende Komponenten meldet, installiere diese über den Installer.

## 2. Bei einem reinen Blueprint-Projekt zuerst C++ ergänzen

Wenn dein Projekt bereits einen eigenen `Source`-Ordner mit C++-Projektcode hat, gehe zu Schritt 3.

Für ein bisher reines Blueprint-Projekt erledigst du Folgendes **vor dem Kopieren des Plugins**:

1. Projekt in Unreal öffnen.
2. **Tools → New C++ Class… / Werkzeuge → Neue C++-Klasse…** wählen.
3. Als Basisklasse **Actor** auswählen.
4. Einen freien Namen vergeben, zum Beispiel `NavigationBuildAnchor`, und die Klasse erstellen.
5. Die Erzeugung bzw. den ersten Build abschließen lassen. Falls ein Buildfehler erscheint, zuerst die C++-Umgebung aus Schritt 1 einrichten.
6. Arbeit speichern und Unreal schließen.

Der Klassenassistent ergänzt die C++-Projektstruktur. Die neue Actor-Klasse muss für dieses Plugin nicht im Level platziert werden. Deine bisherigen Blueprints bleiben verwendbar. Siehe [Epics C++-Klassenassistent](https://dev.epicgames.com/documentation/unreal-engine/using-the-cplusplus-class-wizard-in-unreal-engine?lang=en-US).

## 3. Plugin-Dateien ins Projekt kopieren

1. ZIP von GitHub über **Code → Download ZIP** herunterladen und vollständig entpacken.
2. Im entpackten Paket den Ordner öffnen, der direkt `UniversalEditorNavigation.uplugin` und `Source` enthält.
3. Im Hauptordner deines Unreal-Projekts den Ordner `Plugins` anlegen, falls er noch fehlt. Der Hauptordner ist der Ordner mit deiner `.uproject`-Datei.
4. Darin den Unterordner `UniversalEditorNavigation` anlegen.
5. Den Inhalt des entpackten Plugin-Ordners dorthin kopieren, einschließlich Lizenz und Anleitung.

Die Struktur muss anschließend so aussehen:

```text
MeinProjekt/
├── MeinProjekt.uproject
├── Source/
└── Plugins/
    └── UniversalEditorNavigation/
        ├── UniversalEditorNavigation.uplugin
        ├── Source/
        ├── Resources/
        ├── LICENSE
        ├── README.md
        └── INSTALL-DE.md
```

Die `.uplugin`-Datei liegt direkt in `Plugins/UniversalEditorNavigation`. Ein zusätzlich verschachtelter ZIP-/Repository-Ordner dazwischen ist eine häufige Fehlerquelle. Unreal erkennt Plugins über ihre `.uplugin`-Datei im Plugin-Suchpfad. Siehe [Epics Plugin-Dokumentation](https://dev.epicgames.com/documentation/en-us/unreal-engine/plugins-in-unreal-engine).

## 4. Projektdateien erzeugen und kompilieren

1. Unreal geschlossen lassen.
2. Im Windows-Explorer auf deine `.uproject`-Datei rechtsklicken und **Generate Visual Studio project files / Visual-Studio-Projektdateien generieren** auswählen. Unter Windows 11 kann der Eintrag unter **Weitere Optionen anzeigen** liegen.
3. Die erzeugte Projektlösung `.sln` oder `.slnx` in Visual Studio öffnen.
4. Oben die Konfiguration **Development Editor** und Plattform **Win64** auswählen.
5. Im Projektmappen-Explorer dein Spielprojekt auswählen und mit **Rechtsklick → Build / Erstellen** kompilieren. Das Editor-Ziel heißt üblicherweise `<Projektname>Editor`.
6. Auf einen erfolgreichen Build warten. Die verwendete Unreal-Installation bleibt die vorhandene Engine; der Build erstellt dein Projekt und das Plugin.

Die Plugin-DLL wird dabei im Plugin-Unterordner `Binaries/Win64` erzeugt. `Intermediate` enthält temporäre Build-Dateien. Beide Ordner sind im GitHub-Paket absichtlich nicht enthalten und werden von `.gitignore` ausgeschlossen.

Bei Fehlern in Visual Studio die **Ausgabe / Output** des Builds auf die erste tatsächliche Fehlermeldung prüfen. Grundlagen: [Projektdateien verwalten](https://dev.epicgames.com/documentation/unreal-engine/managing-game-code-in-unreal-engine) und [Unreal-Projekte kompilieren](https://dev.epicgames.com/documentation/en-us/unreal-engine/compiling-game-projects-in-unreal-engine-using-cplusplus).

## 5. Aktivieren und ausprobieren

1. Deine `.uproject`-Datei wieder öffnen.
2. Unter **Edit → Plugins / Bearbeiten → Plugins** nach **Universal Editor Navigation** suchen. Das Plugin ist standardmäßig aktiviert. Falls du es dort erst aktivierst, Unreal nach Aufforderung neu starten.
3. Einen normalen **Perspective-Level-Viewport** verwenden.
4. **RMB + Maus:** frei lokal drehen.
5. **RMB + Q/E halten:** links/rechts rollen. Standard sind 120 Grad pro Sekunde.
6. Nach etwa 90 Grad Seitenlage die Maus horizontal und vertikal bewegen: Beide Achsen sollen weiter relativ zur Kamera reagieren.

Es ist kein Kamera-Actor und kein Play-Modus nötig. Q/E sind bei aktivierter Rollfunktion im fokussierten Perspective-Viewport für Roll reserviert. Ohne RMB erfolgt keine Drehung. Maus-/Rolltasten und Empfindlichkeit stehen unter **Edit → Project Settings → Plugins → Universal Editor Navigation**.

## Häufige Probleme

| Problem | Prüfen |
| --- | --- |
| Plugin wird nicht angezeigt | Liegt die `.uplugin` direkt im richtigen Plugin-Ordner? Nach dem Kopieren Unreal neu starten. |
| Fehlende Module oder „could not be compiled“ | Editor schließen und Schritt 4 ausführen; C++-Toolchain und UE-Version prüfen. |
| Projektdateien lassen sich nicht erzeugen | Hat das Projekt eigenen C++-Code und die passende Unreal-Dateizuordnung? Bei Blueprint-Projekten Schritt 2 durchführen. |
| DLL kann nicht überschrieben werden | Die betreffende Unreal-Editor-Sitzung schließen und erneut bauen. |
| Q/E steuern keine normalen Gizmos mehr | Die Tasten sind bei aktiver Rollfunktion reserviert; `Enable Roll` ausschalten, um die normalen Belegungen zurückzuerhalten. |
| Maus reagiert nach Roll wieder eingeschränkt | `Enable Navigation (Local Rotation)` und `Enable Local Mouse Look` einschalten. |
| Keine Plugin-Navigation | Perspective-Viewport fokussieren, RMB halten und Kamera-/Actor-Lock bzw. laufende PIE-/Simulationssitzung beenden. Native Rotationsphysik bleibt ausgeschlossen. |

## Deaktivieren oder entfernen

Zum sofortigen Abschalten unter **Project Settings → Plugins → Universal Editor Navigation** den Schalter `Enable Navigation (Local Rotation)` deaktivieren. Nur Roll lässt sich separat mit `Enable Roll` ausschalten.

Zum vollständigen Deaktivieren unter **Edit → Plugins** den Plugin-Haken entfernen und Unreal neu starten. Für eine Entfernung anschließend Unreal schließen, den Plugin-Ordner an einen Sicherungsort außerhalb von `Plugins` verschieben und das Editor-Ziel erneut bauen. Projektassets und Level bleiben erhalten.

Die aktuelle Version stellt lokale Rotation bereit. WASD und Translation bleiben nativ; Ctrl/Space sind noch nicht als lokale Auf-/Ab-Bewegung implementiert. Weitere Grenzen und der Testumfang stehen in [README.md](README.md).
